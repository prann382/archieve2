# urls.py

from django.contrib import admin
from django.urls import path
from myapp import views  # Import your views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.register_student, name='register_student'),  # Set the root URL to register_student view
    path('registration_success/', views.registration_success, name='registration_success'),
]
